#include "StdAfx.h"
#include "TAS_ItemRong.h"
#include "Console.h"

CLASS_ITEM00 GCLASS_ITEM00;
void CLASS_ITEM00::SendData(GS_ITEM00* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM06 GCLASS_ITEM06;
void CLASS_ITEM06::SendData(GS_ITEM06* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM07 GCLASS_ITEM07;
void CLASS_ITEM07::SendData(GS_ITEM07* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM08 GCLASS_ITEM08;
void CLASS_ITEM08::SendData(GS_ITEM08* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM09 GCLASS_ITEM09;
void CLASS_ITEM09::SendData(GS_ITEM09* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM10 GCLASS_ITEM10;
void CLASS_ITEM10::SendData(GS_ITEM10* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM11 GCLASS_ITEM11;
void CLASS_ITEM11::SendData(GS_ITEM11* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM12 GCLASS_ITEM12;
void CLASS_ITEM12::SendData(GS_ITEM12* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}

CLASS_ITEM13 GCLASS_ITEM13;
void CLASS_ITEM13::SendData(GS_ITEM13* lpMsg)
{
	this->ItemRong = lpMsg->ItemRong;
}
