#pragma once

class NPC {
public:
	void        Load();
	// ----
	static void ElfSoldier();
	static void Marlon();
	static void ChaosCardMaster();
	static void Guard1();
	static void Guard2();
	static void CursedWizard();


	// ----
}; extern NPC gNPC;
// ----------------------------------------------------------------------------------------------