#pragma once 
#if(FIX_GIAM_LAG_MAIN)
void InitReduceCPU();
#endif