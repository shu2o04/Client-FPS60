void CustomRotateChar();
void RotateCharacter();