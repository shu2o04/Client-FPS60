#pragma once

class cFixDarkSide
{
	public:
	cFixDarkSide();
	void Hook();
};

extern cFixDarkSide FixDarkSide;