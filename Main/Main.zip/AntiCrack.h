#include "stdafx.h"

#if(ANTI_CRACK_MAIN == 1)

void MainProtection();
void SystemOut();
inline bool CheckDbgPresentCloseHandle();
inline bool Int2DCheck();
inline bool IsDbgPresentPrefixCheck();

#endif