#pragma once
#include "Object.h"
#include "Protocol.h"

class GCCreateChar
{
	public:
	void Load( );
};

extern GCCreateChar GCCharacter;

