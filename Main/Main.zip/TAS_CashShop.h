#pragma once
class CashShopX
{
	public:
	void Load();
};

extern CashShopX gCashShop;
