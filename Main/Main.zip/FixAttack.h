#pragma once

void FixVisualSpeedAttack();