#include "StdAfx.h"
#include "TAS_CashShop.h"
#include "Offset.h"
#include "Util.h"
#include "Import.h"
#include "WindowsStruct.h"

CashShopX gCashShop;


void CashShopX::Load()
{
	
}
