#pragma once
class CustomNameColor
{
public: 
	static void DivineWeapon();
	static void DropColor();
	void Load();
};
extern CustomNameColor gCustomNameColor;