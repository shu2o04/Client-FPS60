#pragma once
class cFixSkillBeastUppercut
{
	public:
	void Init();
	void Hook();
};

extern cFixSkillBeastUppercut FixSkillBeastUppercut;