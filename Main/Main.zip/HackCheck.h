#pragma once

#define MIN_PORT 55901
#define MAX_PORT 55950

#define PORT_RANGE(x) (((x)<MIN_PORT)?0:((x)>MAX_PORT)?0:1)
static DWORD FPS;
void DecryptData(BYTE* lpMsg,int size);
void EncryptData(BYTE* lpMsg,int size);
bool CheckSocketPort(SOCKET s);
int WINAPI MyRecv(SOCKET s,char* buf,int len,int flags);
int WINAPI MySend(SOCKET s,char* buf,int len,int flags);
void CheckTickCount1();
void CheckTickCount2();
void InitHackCheck();
