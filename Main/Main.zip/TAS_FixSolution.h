#pragma once
class SuaLoiKhungHinh
{
	public:
	float SD_PosY,BP_PosY;
	float HP_PosX, HP_PosY;
	float DotStatus;

	float KillBoss_Text_Y;
	void SuaLoiKhungHinh::StartLoadPos();
};
extern SuaLoiKhungHinh gFixSolution;